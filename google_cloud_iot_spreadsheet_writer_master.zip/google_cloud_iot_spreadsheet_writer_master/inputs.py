SHEET_ID = '1iELcAmb95zvyEIH0uUs5fFiDX-TSNJ5hdqVfXTurtuc'
SHEET_NAME = 'Sheet1'
url = f'https://docs.google.com/spreadsheets/d/{SHEET_ID}/gviz/tq?tqx=out:csv&sheet={SHEET_NAME}'